library(testthat); source('R/load_gapminder.R'); source('R/clean_gapminder.R'); source('R/model_lifeexp.R'); source('R/plot_gapminder.R')
